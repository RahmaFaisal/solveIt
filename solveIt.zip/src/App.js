import './App.css';

import MainLayout  from "./components/main/mainLayout";

function App() {
 

  return (
    <div className="App">
      <MainLayout></MainLayout>
    </div>
  );
}

export default App;
