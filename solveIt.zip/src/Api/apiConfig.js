export const apiConfig={
    baseUrl:'https://gorest.co.in/public-api'
}